package com.windsoft.tcp.library.main;

import com.windsoft.tcp.library.producer.Producer;

public class Service {
    public static void main(String[] args) {
        new Producer().init();
    }
}
